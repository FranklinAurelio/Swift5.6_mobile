import UIKit

var MaybeStr: String? = "i'm not a String"

MaybeStr!.count

func performMagic(spell: String) ->String{
    return spell
}

performMagic(spell: "disappear")

// Clousures
var newMagicFunction = {
    (spell: String)->String in
    return spell;
}

newMagicFunction("disappear")

//Properties
struct Human {
    var name: String = ""
    var heightM: Double = 0.0
    var heightCm: Double{
        get{
            return 100 * heightM
        }
        set(newHeightCm){
            heightM = newHeightCm/100
        }
    }
}

var people1 = Human(name:"Jonh", heightM: 1.9)
people1.heightM
people1.heightCm

people1.heightCm = 210
people1.heightM

extension Double {
    var km: Double { return self * 1_000.0 }
    var m: Double { return self }
    var cm: Double { return self / 100.0 }
    var mm: Double { return self / 1_000.0 }
    var ft: Double { return self / 3.28084 }
}
let oneInch = 25.4.mm
print("One inch is \(oneInch) meters")
// Prints "One inch is 0.0254 meters"
let threeFeet = 3.ft
print("Three feet is \(threeFeet) meters")
// Prints "T
