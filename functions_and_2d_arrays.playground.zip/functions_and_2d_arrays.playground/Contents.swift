import UIKit

func doMath(a:Double, b:Double, operation:String)->Double{
    var result: Double
    switch operation{
    case "+": result = a + b
    case "-": result = a - b
    case "*": result = a * b
    case "/":
        if b > 0.0{
        result = a/b
        }
        else{
            result = 0.0
        }
    default:
        result = 0.0
    }
    print("Performing", operation, "on", a, "and", b, "is equals", result)
    
    return result
}

let result = doMath(a: 2.0, b: 1.0, operation: "/")

// 2D Arrays (basic image processing)
 var image  = [
    [3,7,10],
    [6,4,2],
    [8,5,9]
 ]

func raisLowerValuesOfImage(   image: inout [[Int]]){
    for row in 0..<image.count{
        for col in 0..<image[row].count{
            image[row][col]
            if (image[row][col] < 5){
                image[row][col] = 5
            }
        }
    }
}

raisLowerValuesOfImage( image: &image)
image


