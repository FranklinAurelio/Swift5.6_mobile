import UIKit

let image = UIImage(named: "monet1.png")!
let myRGB = RGBAImage(image: image)!

let x = 10
let y = 10

let index = y * myRGB.width + x
var pixel  = myRGB.pixels[index]

pixel.R
pixel.G
pixel.B

pixel.R = 255
pixel.G = 0
pixel.B = 0

myRGB.pixels[index] = pixel

let newImage = myRGB.toUIImage()

var avgRed = 0
var avgGreen = 0
var avgBlue = 0

//função feita para pbter a media da imagem, não preciso repetir o processo varias vezes durante a execussão

func mediaRGB(image: RGBAImage) ->[Int]{
    var mediaRGB: [Int] = [];
    var mediaRed = 0
    var mediaGreen = 0
    var mediaBlue = 0
    
    for y in 0..<image.height{
        for x in 0..<image.width{
            let index = y * image.width + x
            let pixel = image.pixels[index]
            mediaRed += Int(pixel.R)
            mediaGreen += Int(pixel.G)
            mediaBlue += Int(pixel.B)
        }
    }
    
    let count = image.width * image.height
    let avgRed = mediaRed/count
    let avgGreen = mediaGreen/count
    let avgBlue = mediaBlue/count
    
    mediaRGB.append(avgRed)
    mediaRGB.append(avgGreen)
    mediaRGB.append(avgBlue)
    
    return mediaRGB;
}

var result:[Int] = [];
result = mediaRGB(image: myRGB)

avgRed = result[0]
avgGreen = result[1]
avgBlue = result[2]



func redDifference (image: RGBAImage) -> RGBAImage{
    for y in 0..<image.height{
        for x in 0..<image.width{
            let index = y * image.width + x
            var pixel = image.pixels[index]
            let redDiff = Int(pixel.R) - avgRed
            if(redDiff > 0){
                pixel.R = UInt8(
                    max(
                        0, min (
                            255, avgRed + redDiff * 5)
                    )
                )
                image.pixels[index] = pixel
            }
        }
    }
    return image
}

var myRGBFilterRed: RGBAImage = myRGB
myRGBFilterRed = redDifference(image: myRGB)
myRGBFilterRed.toUIImage()
image
