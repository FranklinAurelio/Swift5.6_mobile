import UIKit

//Closures
let names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]

func backward(_ s1: String, _ s2: String) -> Bool {
    return s1 > s2
}
var reversedNames = names.sorted(by: backward)

/*Sintaxe*/
/*
 { (parameters) -> return type in
     statements
 }
 */
reversedNames = names.sorted(by: { (s1: String, s2: String) -> Bool in
    return s1 > s2
})

let digitNames = [
    0: "Zero", 1: "One", 2: "Two",   3: "Three", 4: "Four",
    5: "Five", 6: "Six", 7: "Seven", 8: "Eight", 9: "Nine"
]
let numbers = [16, 58, 510]

let strings = numbers.map { (number) -> String in
    var number = number
    var output = ""
    repeat {
        output = digitNames[number % 10]! + output
        number /= 10
    } while number > 0
    return output
}

//class and structures

struct Resolution {
    var width = 0
    var height = 0
}
class VideoMode {
    var resolution = Resolution()
    var interlaced = false
    var frameRate = 0.0
    var name: String?
}
let someResolution = Resolution()
let someVideoMode = VideoMode()

// types
class number {
    var n: Int
    init(n:Int){
        self.n = n
    }
}

var aNumber = number(n: 3)
var bNumber = aNumber

bNumber.n = 5
aNumber.n

struct valueNumber {
    var n: Int
    init(n:Int){
        self.n = n
    }
}

var xNumber = valueNumber(n: 3)
var yNumber = xNumber

yNumber.n = 5
xNumber.n

/*
 classes são copiadas por referencia, ja structs não
 */
