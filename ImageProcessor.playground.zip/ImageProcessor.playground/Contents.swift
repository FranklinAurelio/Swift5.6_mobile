//: Playground - noun: a place where people can play

import UIKit


/*let x = 10
let y = 10

let index = y * myRGB.width + x
var pixel  = myRGB.pixels[index]

pixel.R
pixel.G
pixel.B

pixel.R = 255
pixel.G = 0
pixel.B = 0

myRGB.pixels[index] = pixel

let newImage = myRGB.toUIImage()

var avgRed = 0
var avgGreen = 0
var avgBlue = 0

//função feita para pbter a media da imagem, não preciso repetir o processo varias vezes durante a execussão

func mediaRGB(image: RGBAImage) ->[Int]{
    var mediaRGB: [Int] = [];
    var mediaRed = 0
    var mediaGreen = 0
    var mediaBlue = 0
    
    for y in 0..<image.height{
        for x in 0..<image.width{
            let index = y * image.width + x
            let pixel = image.pixels[index]
            mediaRed += Int(pixel.R)
            mediaGreen += Int(pixel.G)
            mediaBlue += Int(pixel.B)
        }
    }
    
    let count = image.width * image.height
    let avgRed = mediaRed/count
    let avgGreen = mediaGreen/count
    let avgBlue = mediaBlue/count
    
    mediaRGB.append(avgRed)
    mediaRGB.append(avgGreen)
    mediaRGB.append(avgBlue)
    
    return mediaRGB;
}

var result:[Int] = [];
result = mediaRGB(image: myRGB)

avgRed = result[0]
avgGreen = result[1]
avgBlue = result[2]



func redDifference (image: RGBAImage) -> RGBAImage{
    for y in 0..<image.height{
        for x in 0..<image.width{
            let index = y * image.width + x
            var pixel = image.pixels[index]
            let redDiff = Int(pixel.R) - avgRed
            if(redDiff > 0){
                pixel.R = UInt8(
                    max(
                        0, min (
                            255, avgRed + redDiff * 5)
                    )
                )
                image.pixels[index] = pixel
            }
        }
    }
    return image
}

var myRGBFilterRed: RGBAImage = myRGB
myRGBFilterRed = redDifference(image: myRGB)
myRGBFilterRed.toUIImage()
image*/

let image = UIImage(named: "sample.png")!
let myRGB = RGBAImage(image: image)!
let myRGB1 = RGBAImage(image: image)!
let myRGB2 = RGBAImage(image: image)!
let myRGB3 = RGBAImage(image: image)!
let myRGB4 = RGBAImage(image: image)!
let myRGB5 = RGBAImage(image: image)!


class ImageProcessing{
    var result:[Int] = [];
    var avgRed = 0
    var avgGreen = 0
    var avgBlue = 0
    
    func mediaRGB(image: RGBAImage) ->[Int]{
        var mediaRGB: [Int] = [];
        var mediaRed = 0
        var mediaGreen = 0
        var mediaBlue = 0
        
        for y in 0..<image.height{
            for x in 0..<image.width{
                let index = y * image.width + x
                let pixel = image.pixels[index]
                mediaRed += Int(pixel.R)
                mediaGreen += Int(pixel.G)
                mediaBlue += Int(pixel.B)
            }
        }
        
        let count = image.width * image.height
        let avgRed = mediaRed/count
        let avgGreen = mediaGreen/count
        let avgBlue = mediaBlue/count
        
        mediaRGB.append(avgRed)
        mediaRGB.append(avgGreen)
        mediaRGB.append(avgBlue)
        
        return mediaRGB;
    }
    
    init(){
        self.result = mediaRGB(image: myRGB)
        self.avgRed = result[0]
        self.avgGreen = result[1]
        self.avgBlue = result[2]
        
    }
   
    
    func redDifference (image: RGBAImage) -> RGBAImage{
        for y in 0..<image.height{
            for x in 0..<image.width{
                let index = y * image.width + x
                var pixel = image.pixels[index]
                let redDiff = Int(pixel.R) - avgRed
                if(redDiff > 0){
                    pixel.R = UInt8(
                        max(
                            0, min (
                                255, avgRed + redDiff * 5)
                        )
                    )
                    image.pixels[index] = pixel
                }
            }
        }
        return image
    }
    
    func sludge(image: RGBAImage) -> RGBAImage{
        for y in 0..<image.height{
            for x in 0..<image.width{
                let index = y * image.width + x
                var pixel = image.pixels[index]
                let redDiff = Int(pixel.R)
                if(redDiff > 0){
                    pixel.R = UInt8(
                        max(
                            0, min (
                                255, redDiff/2)
                        )
                    )
                    image.pixels[index] = pixel
                }
                let greenDiff = Int(pixel.G)
                if(greenDiff > 0){
                    pixel.G = UInt8(
                        max(
                            0, min (
                                255,  greenDiff/2)
                        )
                    )
                    image.pixels[index] = pixel
                }
                let blueDiff = Int(pixel.B)
                if(blueDiff > 0){
                    pixel.B = UInt8(
                        max(
                            0, min (
                                255,  blueDiff/2)
                        )
                    )
                    image.pixels[index] = pixel
                }
            }
        }
        return image
    }
    
    func intensification(image: RGBAImage) -> RGBAImage{
        for y in 0..<image.height{
            for x in 0..<image.width{
                let index = y * image.width + x
                var pixel = image.pixels[index]
                let redDiff = Int(pixel.R) - avgRed
                if(redDiff > 0){
                    pixel.R = UInt8(
                        max(
                            0, min (
                                255, redDiff*3)
                        )
                    )
                    image.pixels[index] = pixel
                }
                let greenDiff = Int(pixel.G)-avgGreen
                if(greenDiff > 0){
                    pixel.G = UInt8(
                        max(
                            0, min (
                                255,  greenDiff*3)
                        )
                    )
                    image.pixels[index] = pixel
                }
                let blueDiff = Int(pixel.B) - avgBlue
                if(blueDiff > 0){
                    pixel.B = UInt8(
                        max(
                            0, min (
                                255,  blueDiff*3)
                        )
                    )
                    image.pixels[index] = pixel
                }
            }
        }
        return image
    }
    
    func old(image: RGBAImage) -> RGBAImage{
        for y in 0..<image.height{
            for x in 0..<image.width{
                let index = y * image.width + x
                var pixel = image.pixels[index]
                let redDiff = Int(pixel.R) - avgRed
                if(redDiff > 0){
                    pixel.R = UInt8(
                        max(
                            0, min (
                                255, avgRed+redDiff*3)
                        )
                    )
                    image.pixels[index] = pixel
                }
                let greenDiff = Int(pixel.G) - avgGreen
                if(greenDiff > 0){
                    pixel.G = UInt8(
                        max(
                            0, min (
                                255, avgGreen+greenDiff*2)
                        )
                    )
                    image.pixels[index] = pixel
                }
                let blueDiff = Int(pixel.B)
                if(blueDiff > 0){
                    pixel.B = UInt8(
                        max(
                            0, min (
                                255,  avgBlue+blueDiff/1,3)
                        )
                    )
                    image.pixels[index] = pixel
                }
            }
        }
        return image
    }
    
    
    func yellowIntensification(image: RGBAImage) -> RGBAImage{
        for y in 0..<image.height{
            for x in 0..<image.width{
                let index = y * image.width + x
                var pixel = image.pixels[index]
              
                let greenDiff = Int(pixel.G) - avgGreen
                if(greenDiff > 0){
                    pixel.G = UInt8(
                        max(
                            0, min (
                                255, avgGreen+greenDiff*2)
                        )
                    )
                    image.pixels[index] = pixel
                }
                let blueDiff = Int(pixel.B) - avgBlue
                if(blueDiff > 0){
                    pixel.B = UInt8(
                        max(
                            0, min (
                                255,  avgBlue+blueDiff*3)*0,6
                        )
                    )
                    image.pixels[index] = pixel
                }
            }
        }
        return image
    }
    
    func SelectFilter(filter:String, image:RGBAImage) ->RGBAImage{
        var imageOut:RGBAImage = myRGB;
        switch filter{
        case "redDifference" :
           imageOut = redDifference(image: image)
        case "sludge":
            imageOut = sludge(image: image)
        case "intensification":
            imageOut = intensification(image: image)
        case "old":
            imageOut = old(image: image)
        case "yellowIntensification":
            imageOut = yellowIntensification(image: image)
        default:
            print("choose a filter")
        }
        
        return imageOut
    }
    
}
myRGB.toUIImage()
var _imageProcessing = ImageProcessing()
var out = _imageProcessing.redDifference(image: myRGB)
out.toUIImage()
var out1 = _imageProcessing.sludge(image: myRGB1)
out1.toUIImage()
var out2 = _imageProcessing.intensification(image: myRGB2)
out2.toUIImage()

var out3 = _imageProcessing.old(image: myRGB3)
out3.toUIImage()

var out4 = _imageProcessing.yellowIntensification(image: myRGB4)
out4.toUIImage()

var outFunction = _imageProcessing.SelectFilter(filter: "sludge", image: myRGB5)
outFunction.toUIImage()

// Process the image!

