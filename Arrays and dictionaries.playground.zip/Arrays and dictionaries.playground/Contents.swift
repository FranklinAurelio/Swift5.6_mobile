import UIKit

var greeting = "Hello, playground"
var animals:[String] = ["cow", "dog", "bunny"]
animals[1]
//animals[1] = "rabbit"
animals[1]
for animal in animals {
    animal
}

//hash
var cutness = ["cow":"not very",
               "dog":"cute",
               "bunny":"very cute"]
cutness["dog"]

