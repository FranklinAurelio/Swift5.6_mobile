import UIKit
import Foundation

class SuperNumber : NSNumber{
    override func getValue(_ value: UnsafeMutableRawPointer, size: Int) {
        super.getValue(value)
    }
}
extension NSNumber {
    func superCoolGetter() -> Int{
        return 5
    }
}

let n = NSNumber(4)
n.superCoolGetter()

protocol dancable{
    func dance()
}

class Person: dancable{
    func dance() {
        <#code#>
    }
}

enum TypeOfVeggies: String {
    case Carrots
    case Tomatoes
    case Calery
}

let carrot = TypeOfVeggies.Carrots
carrot.rawValue

func eatVeggies(veggie: TypeOfVeggies){
    
}

let randomVeggie  = TypeOfVeggies(rawValue: "Carrots")
eatVeggies(veggie: TypeOfVeggies.Carrots)

class CarWithCups{
    var cupHolder: String
    required init(cupHolder: String){
        self.cupHolder = cupHolder
        //super.init()
    }
    convenience init(){
        self.init(cupHolder:"cool")
    }
    
    deinit{
        
    }
    /*required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }*/
}


//consigo saber qual inicializador  estou usando pelos arqumentos passados
let car = CarWithCups(cupHolder: "cool")
let newCar = CarWithCups()

//generics

var a =  Array<Any>()
a.self
a.append("d")
a.append(1)
a.self
